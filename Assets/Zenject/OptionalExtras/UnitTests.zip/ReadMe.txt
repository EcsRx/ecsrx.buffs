
Note that the UnitTests here require that you also include the TestingFramework folder in your project as well.

