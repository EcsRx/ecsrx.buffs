﻿using UnityEngine;

namespace Zenject.Tests.ToPrefabResource
{
    public class Bar : MonoBehaviour
    {
    }
}
