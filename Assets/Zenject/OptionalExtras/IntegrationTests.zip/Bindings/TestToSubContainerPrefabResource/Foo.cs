﻿using UnityEngine;

namespace Zenject.Tests.ToSubContainerPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
