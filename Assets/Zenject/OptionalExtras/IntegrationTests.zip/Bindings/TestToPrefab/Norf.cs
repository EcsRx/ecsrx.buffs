using System;
using UnityEngine;

namespace Zenject.Tests.ToPrefab
{
    public interface INorf
    {
    }

    public class Norf : MonoBehaviour, INorf
    {
    }
}
