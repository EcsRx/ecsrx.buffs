using System;
using UnityEngine;

namespace Zenject.Tests.ToPrefab
{
    public class Norf2 : MonoBehaviour, INorf
    {
    }
}

